<?php
/**
 * 2007-2022 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2022 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */
if (!defined('_PS_VERSION_')) {
    exit;
}
class Geolocation extends Module
{
    public function __construct()
    {
        $this->name = 'geolocation';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'VenVaukt';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.6',
            'max' => _PS_VERSION_,
        ];
        $this->bootstrap = true;
        parent::__construct();
        $this->displayName = $this->l('Geolocation Module ');
        $this->description = $this->l('This module detect location of user and set Currency');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
        if (!Configuration::get('MYMODULE_NAME')) {
            $this->warning = $this->l('No name provided');
        }
    }
    public function install()
    {
        Configuration::updateValue('FAVICON_SELECT_POS', 1);

        Configuration::updateValue('Use_Popup', 1);

        Configuration::updateValue('BackgroundOfPopUp', '#ffffff');

        Configuration::updateValue('TextColor', '#000000');

        Configuration::updateValue('buttonBackground', '#000000');

        Configuration::updateValue('TextButtonColor', '#fff');

        return parent::install()
            && $this->registerHook('header');
    }
    /**
     * uninstall module
     * @return bool
     */
    public function uninstall()
    {
        Configuration::deleteByName('FAVICON_SELECT_POS');

        Configuration::deleteByName('Use_Popup');

        Configuration::deleteByName('BackgroundOfPopUp');

        Configuration::deleteByName('TextColor');

        Configuration::deleteByName('buttonBackground');

        Configuration::deleteByName('TextButtonColor');

        Configuration::deleteByName('MYMODULE_NAME');

        return parent::uninstall();
    }
    public function getContent()
    {
        if (Tools::isSubmit('submit' . $this->name)) {
            $this->saveProcess();
        } elseif (Tools::isSubmit('del' . $this->name)) {
            $this->deleteProcess();
        }
        return $this->displayForm();
    }
    /**
     * save data
     */
    public function saveProcess()
    {
        $configPos = Tools::getValue('FAVICON_SELECT_POS');
        $configUsePopup = Tools::getValue('Use_Popup');
        $languages = Language::getLanguages(false);
        Configuration::updateValue('FAVICON_SELECT_POS', $configPos);

        Configuration::updateValue('Use_Popup', $configUsePopup);

        Configuration::updateValue('BackgroundOfPopUp', Tools::getValue('BackgroundOfPopUp'));

        Configuration::updateValue('TextColor', Tools::getValue('TextColor'));

        Configuration::updateValue('buttonBackground', Tools::getValue('buttonBackground'));

        Configuration::updateValue('TextButtonColor', Tools::getValue('TextButtonColor'));
    }
    /**
     * display form
     */
    public function displayForm()
    {
        $default_lang = (int) Configuration::get('PS_LANG_DEFAULT');
        $form = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Settings'),
                ],
                'input' => [
                    [
                        'type' => 'switch',
                        'label' => 'Activate this Module',
                        'name' => 'FAVICON_SELECT_POS',
                        'values' => [
                            [
                                'value' => 1,
                                'label' => $this->trans('Yes', [], 'Admin.Global'),
                            ],
                            [
                                'value' => 0,
                                'label' => $this->trans('No', [], 'Admin.Global'),
                            ],
                        ],
                    ],
                    [
                        'type' => 'switch',
                        'label' => 'Do you want to use Pop up',
                        'name' => 'Use_Popup',
                        'values' => [
                            [
                                'value' => 1,
                                'label' => $this->trans('Yes', [], 'Admin.Global'),
                            ],
                            [
                                'value' => 0,
                                'label' => $this->trans('No', [], 'Admin.Global'),
                            ],
                        ],
                    ],
                    [
                        'type' => 'color',
                        'name' => 'BackgroundOfPopUp',
                        'label' => $this->l('Background Color of the Popup'),
                        'desc' => $this->l('Choose new Background Color for the Popup of geolocation'),
                    ],
                    [
                        'type' => 'color',
                        'name' => 'TextColor',
                        'label' => $this->l('Color of all Text of Popup'),
                        'desc' => $this->l('Choose new Text Color for your Popup'),
                    ],
                    [
                        'type' => 'color',
                        'name' => 'buttonBackground',
                        'label' => $this->l('Background Color of All Buttons of Popup'),
                        'desc' => $this->l('Choose new Background Color for the Buttons'),
                    ],
                    [
                        'type' => 'color',
                        'name' => 'TextButtonColor',
                        'label' => $this->l('Color of text Buttons'),
                        'desc' => $this->l('Choose new Color for the Text Buttons'),
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Save'),
                    'class' => 'btn btn-default pull-right',
                ],
            ],
        ];
        $helper = new HelperForm();
        $helper->table = $this->table;
        $helper->name_controller = $this->name;
        $helper->show_cancel_button = true;
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&' . http_build_query(['configure' => $this->name]);
        $helper->submit_action = 'submit' . $this->name;
        foreach (Language::getLanguages(false) as $lang) {
            $helper->languages[] = [
                'id_lang' => $lang['id_lang'],
                'iso_code' => $lang['iso_code'],
                'name' => $lang['name'],
                'is_default' => ($default_lang == $lang['id_lang'] ? 1 : 0),
            ];
        }
        $helper->fields_value['FAVICON_SELECT_POS'] = Tools::getValue('FAVICON_SELECT_POS', Configuration::get('FAVICON_SELECT_POS'));
        $helper->fields_value['Use_Popup'] = Tools::getValue('Use_Popup', Configuration::get('Use_Popup'));
        $helper->fields_value['BackgroundOfPopUp'] = Tools::getValue('BackgroundOfPopUp', Configuration::get('BackgroundOfPopUp'));
        $helper->fields_value['TextColor'] = Tools::getValue('TextColor', Configuration::get('TextColor'));
        $helper->fields_value['buttonBackground'] = Tools::getValue('buttonBackground', Configuration::get('buttonBackground'));
        $helper->fields_value['TextButtonColor'] = Tools::getValue('TextButtonColor', Configuration::get('TextButtonColor'));
        return $helper->generateForm([$form]);
    }
    public function getIpAddress()
    {
        $ipAddress = '';
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            // to get shared ISP IP address
            $ipAddress = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            // check for IPs passing through proxy servers
            // check if multiple IP addresses are set and take the first one
            $ipAddressList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            foreach ($ipAddressList as $ip) {
                if (!empty($ip)) {
                    // if you prefer, you can check for valid IP address here
                    $ipAddress = $ip;
                    break;
                }
            }
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED'])) {
            $ipAddress = $_SERVER['HTTP_X_FORWARDED'];
        } elseif (!empty($_SERVER['HTTP_X_CLUSTER_CLIENT_IP'])) {
            $ipAddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_FORWARDED_FOR'])) {
            $ipAddress = $_SERVER['HTTP_FORWARDED_FOR'];
        } elseif (!empty($_SERVER['HTTP_FORWARDED'])) {
            $ipAddress = $_SERVER['HTTP_FORWARDED'];
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ipAddress = $_SERVER['REMOTE_ADDR'];
        }
        return $ipAddress;
    }
    public function country_code_to_locale($country_code, $language_code = '')
    {
        /*Locale list taken from:
        http://stackoverflow.com/questions/3191664/
        list-of-all-locales-and-their-short-codes
        */
        $locales = ['af-ZA', 'am-ET', 'ar-AE', 'ar-BH', 'ar-DZ', 'ar-EG', 'ar-IQ', 'ar-JO', 'ar-KW', 'ar-LB', 'ar-LY', 'ar-MA', 'arn-CL', 'ar-OM', 'ar-QA', 'ar-SA', 'ar-SY', 'ar-TN', 'ar-YE', 'as-IN', 'az-Cyrl-AZ', 'az-Latn-AZ', 'ba-RU', 'be-BY', 'bg-BG', 'bn-BD', 'bn-IN', 'bo-CN', 'br-FR', 'bs-Cyrl-BA', 'bs-Latn-BA', 'ca-ES', 'co-FR', 'cs-CZ', 'cy-GB', 'da-DK', 'dv-MV', 'el-GR', 'en-029', 'en-AU', 'en-BZ', 'en-CA', 'en-GB', 'en-IE', 'en-IN', 'en-JM', 'en-MY', 'en-NZ', 'en-PH', 'en-SG', 'en-TT', 'en-US', 'en-ZA', 'en-ZW', 'es-AR', 'es-BO', 'es-CL', 'es-CO', 'es-CR', 'es-DO', 'es-EC', 'es-ES', 'es-GT', 'es-HN', 'es-MX', 'es-NI', 'es-PA', 'es-PE', 'es-PR', 'es-PY', 'es-SV', 'es-US', 'es-UY', 'es-VE', 'et-EE', 'eu-ES', 'fa-IR', 'fi-FI', 'fil-PH', 'fo-FO', 'fr-BE', 'fr-CA', 'fr-CH', 'fr-FR', 'fr-LU', 'fr-MC', 'fy-NL', 'ga-IE', 'gd-GB', 'gl-ES', 'gsw-FR', 'gu-IN', 'ha-Latn-NG', 'he-IL', 'hi-IN', 'hr-BA', 'hr-HR', 'hsb-DE', 'hu-HU', 'hy-AM', 'id-ID', 'ig-NG', 'ii-CN', 'is-IS', 'it-CH', 'it-IT', 'iu-Cans-CA', 'iu-Latn-CA', 'ja-JP', 'ka-GE', 'kk-KZ', 'kl-GL', 'km-KH', 'kn-IN', 'kok-IN', 'ko-KR', 'ky-KG', 'lb-LU', 'lo-LA', 'lt-LT', 'lv-LV', 'mi-NZ', 'mk-MK', 'ml-IN', 'mn-MN', 'mn-Mong-CN', 'moh-CA', 'mr-IN', 'ms-BN', 'ms-MY', 'mt-MT', 'nb-NO', 'ne-NP', 'nl-BE', 'nl-NL', 'nn-NO', 'nso-ZA', 'oc-FR', 'or-IN', 'pa-IN', 'pl-PL', 'prs-AF', 'ps-AF', 'pt-BR', 'pt-PT', 'qut-GT', 'quz-BO', 'quz-EC', 'quz-PE', 'rm-CH', 'ro-RO', 'ru-RU', 'rw-RW', 'sah-RU', 'sa-IN', 'se-FI', 'se-NO', 'se-SE', 'si-LK', 'sk-SK', 'sl-SI', 'sma-NO', 'sma-SE', 'smj-NO', 'smj-SE', 'smn-FI', 'sms-FI', 'sq-AL', 'sr-Cyrl-BA', 'sr-Cyrl-CS', 'sr-Cyrl-ME', 'sr-Cyrl-RS', 'sr-Latn-BA', 'sr-Latn-CS', 'sr-Latn-ME', 'sr-Latn-RS', 'sv-FI', 'sv-SE', 'sw-KE', 'syr-SY', 'ta-IN', 'te-IN', 'tg-Cyrl-TJ', 'th-TH', 'tk-TM', 'tn-ZA', 'tr-TR', 'tt-RU', 'tzm-Latn-DZ', 'ug-CN', 'uk-UA', 'ur-PK', 'uz-Cyrl-UZ', 'uz-Latn-UZ', 'vi-VN', 'wo-SN', 'xh-ZA', 'yo-NG', 'zh-CN', 'zh-HK', 'zh-MO', 'zh-SG', 'zh-TW', 'zu-ZA'];
        foreach ($locales as $locale) {
            $locale_region = locale_get_region($locale);
            $locale_language = locale_get_primary_language($locale);
            $locale_array = ['language' => $locale_language, 'region' => $locale_region];
            if (strtoupper($country_code) == $locale_region && $language_code == '') {
                return locale_compose($locale_array);
            } elseif (strtoupper($country_code) == $locale_region && strtolower($language_code) == $locale_language) {
                return locale_compose($locale_array);
            }
        }
        return null;
    }
    public function hookHeader()
    {
        $ActivateThisAction = Configuration::get('FAVICON_SELECT_POS');
        $UsePopUp = Configuration::get('Use_Popup');
        if ($ActivateThisAction == 1) {
            if (empty($this->context->cookie->existAllready)) {
                $this->context->cookie->existAllready = 'ValueIsAdded';
                $ipaddress = getenv('REMOTE_ADDR');
                $linkShop = Tools::getShopProtocol();
                if (__PS_BASE_URI__) {
                    $linkServer = Tools::getServerName() . __PS_BASE_URI__;
                } else {
                    $linkServer = Tools::getServerName();
                }
                $NameOfShop = Configuration::get('PS_SHOP_NAME');
                $ip = $this->getIpAddress();
                // $ip = "102.128.165.0" ; // Germany
                $Lang_Exist = false;
                $Currency_Exist = false;
                /*
                    Just For Test I use This Ip Adresses Of Countrys
                    $ip = "102.128.165.0" ; // Germany
                    $ip = "103.232.172.0" ; // France
                    $ip = "41.142.209.46" ; // Morroco
                    $ip = "100.255.255.255" ; // USA
                    echo "<h1>" .$_SERVER['REMOTE_ADDR']. "</h1>" ;
                    echo "<h2>" . $ip . "</h2>" ;
                    if($ip != $_SERVER['REMOTE_ADDR']){
                    */
                $ipdat = @json_decode(Tools::file_get_contents('http://www.geoplugin.net/json.gp?ip=' . $ip));
                /*$logger = new FileLogger(0); //0 == debug level, logDebug() won’t work without this.
                $logger->setFilename(_PS_ROOT_DIR_."/log/debug.log");
                $logger->logDebug($_SERVER['REMOTE_ADDR']);
                $logger->logDebug($ipdat);*/
                $CurrencyCode = $ipdat->geoplugin_currencyCode;
                $ContryCode = $ipdat->geoplugin_countryCode;
                $CodeCountryLang = $this->country_code_to_locale($ContryCode, $language_code = '');
                $NameOfCountry = $ipdat->geoplugin_countryName;
                $CountryImgLink = '/modules/geolocation/views/img/' . $ContryCode . '.png';
                $NameOfStore = Configuration::get('PS_SHOP_NAME');
                $linkLang = '';
                $lang = "n'exist pas dans cette Store";
                $Languages = Language::getLanguages(true);
                foreach ($Languages as $key => $value) {
                    if (substr($Languages[$key]['locale'], -2) == substr($CodeCountryLang, -2)) {
                        $lang = $Languages[$key]['name'];
                        $freegeo_language = $Languages[$key]['id_lang'];
                        $Iso_Code = $Languages[$key]['iso_code'];
                        $linkLang = $linkShop . $linkServer . $Iso_Code . '/';
                        $Lang_Exist = true;
                    }
                }
                $conversion_rate = Currency::getCurrencies();
                foreach ($conversion_rate as $key => $value) {
                    if ($conversion_rate[$key]['iso_code'] == $CurrencyCode) {
                        $freegeo_currency = $conversion_rate[$key]['id'];
                        $Currency_Exist = true;
                    }
                }
                // }
                if ($Lang_Exist == false && $Currency_Exist == false) {
                    return;
                }
                $userlangauge = '';
                $userCurency = '';
                if ($Lang_Exist == true) {
                    if ($Currency_Exist == true) {
                        $linkLang = $linkLang . '?SubmitCurrency=1&id_currency=' . $freegeo_currency;
                    }
                }
                if ($Currency_Exist == true) {
                    if ($Lang_Exist == false) {
                        $Languages = Language::getLanguage(true)['iso_code'];
                        $linkLang = $linkShop . $linkServer . $Languages . '/?SubmitCurrency=1&id_currency=' . $freegeo_currency;
                    }
                }
                if ($UsePopUp) {
                    echo "<link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>";

                    echo "<link href='https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp' rel='stylesheet'>";
                    Media::addJsDef([
                        'Link' => $linkLang,
                    ]);
                    $this->context->controller->addJS([
                        $this->_path . 'views/js/index.js',
                    ]);
                    $this->context->controller->addCSS([
                        $this->_path . '/views/css/style.css',
                    ]);
                    $Parrams = ['NameOfStore' => $NameOfStore,
                    'NameOfCountry' => $NameOfCountry,
                    'CountryImgLink' => $CountryImgLink,
                    'userlangauge' => $userlangauge,
                    'userCurency' => $userCurency,
                    'Lang_Exist' => $Lang_Exist,
                    'Currency_Exist' => $Currency_Exist,
                    'language' => $lang,
                    'CurrencyCode' => $CurrencyCode,
                    'Test' => $UsePopUp,
                    'backgroundPopup' => Configuration::get('BackgroundOfPopUp'),
                    'TextColor' => Configuration::get('TextColor'),
                    'buttonBackground' => Configuration::get('buttonBackground'),
                    'TextButtonColor' => Configuration::get('TextButtonColor'),
                        ];
                    $this->smarty->assign($Parrams);
                    return $this->display(__FILE__, '/views/templates/admin/configure.tpl');
                } else {
                    Tools::redirect($linkLang);
                    // header('Location: '.  );
                }
            }
        }
    }
}
