/**
* DISCLAIMER
*
* Do not edit or add to this file.
* You are not authorized to modify, copy or redistribute this file.
* Permissions are reserved by FME Modules.
*
* @author FMM Modules
* @copyright FME Modules 2021
* @license Single domain
*/

$(document).ready(function() 
{

  let btnChangeLang = document.querySelector("#ChangeLang") ;
  btnChangeLang.addEventListener("click",function(){
    if(Link != ""){
      window.location.replace(Link);
    }else{
      alert("your language is not used im store") ;
    }
    
  }) ;

  function CloseModal(){
    document.querySelector(".modal-dialog").style.display = "none" ;
    document.body.style.overflowY = "auto";
    window.location.reload();
  };


  let BtnClose = document.querySelector("#CloseModal") ;
  let BtnClose2 = document.querySelector("#CloseModal2") ;
  let backgroudModal = document.querySelector("#index > .modal-dialog > div.Container-Modal") ; 

  BtnClose.addEventListener("click",function(){
    CloseModal() ;
  }) 

  BtnClose2.addEventListener("click",function(){
    CloseModal() ;
  }) 

  backgroudModal.addEventListener("click",function(){
    CloseModal() ;
  }) 

  

});
